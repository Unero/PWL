<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Hello World in CodeIgniter</title>
</head>
<body>

<div id="container">
	<!-- Direct dari view -->
	<h1 align="center">Bukan Hello World</h1>
</div>

</body>
</html>