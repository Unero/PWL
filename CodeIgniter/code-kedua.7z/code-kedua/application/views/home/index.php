
    <?php foreach ($nama as $mhs_name) {
        ?>
        <h1>Hello, <?php echo $mhs_name;?></h1>
        <?php
    } 
    ?>
